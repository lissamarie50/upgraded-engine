import manifest from '../../plugin.json';

export default manifest;
export const id = manifest.id;
export const version = manifest.version;
