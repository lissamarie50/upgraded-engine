# Focalboard Plugin for Mattermost

This plugin allows to run focalboard inside your mattermost instance as a plugin.
