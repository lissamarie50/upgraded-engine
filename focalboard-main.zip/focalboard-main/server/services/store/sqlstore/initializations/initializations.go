//go:generate go-bindata -prefix templates/ -pkg initializations -o bindata.go ./templates
package initializations
