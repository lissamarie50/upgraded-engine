DROP TABLE {{.prefix}}system_settings;
