DROP TABLE {{.prefix}}sharing;
