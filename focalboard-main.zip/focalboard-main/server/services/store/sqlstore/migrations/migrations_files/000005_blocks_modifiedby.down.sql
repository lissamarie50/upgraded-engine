ALTER TABLE {{.prefix}}blocks
DROP COLUMN modified_by;
