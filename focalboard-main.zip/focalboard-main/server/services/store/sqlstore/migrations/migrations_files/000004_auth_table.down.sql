DROP TABLE {{.prefix}}users;
DROP TABLE {{.prefix}}sessions;
