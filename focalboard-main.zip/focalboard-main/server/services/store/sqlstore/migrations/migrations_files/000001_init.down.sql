DROP TABLE {{.prefix}}blocks;
