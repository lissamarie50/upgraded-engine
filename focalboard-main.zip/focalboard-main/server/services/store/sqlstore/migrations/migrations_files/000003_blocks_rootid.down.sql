ALTER TABLE {{.prefix}}blocks
DROP COLUMN root_id;
