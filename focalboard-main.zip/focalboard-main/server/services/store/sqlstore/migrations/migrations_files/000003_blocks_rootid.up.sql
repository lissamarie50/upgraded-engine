ALTER TABLE {{.prefix}}blocks
ADD COLUMN root_id VARCHAR(36);
