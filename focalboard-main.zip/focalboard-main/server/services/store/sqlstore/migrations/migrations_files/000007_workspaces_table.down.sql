DROP TABLE {{.prefix}}workspaces;
