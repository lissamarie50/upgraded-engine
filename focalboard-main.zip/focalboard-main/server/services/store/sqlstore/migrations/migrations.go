//go:generate go-bindata -prefix migrations_files/ -pkg migrations -o bindata.go ./migrations_files
package migrations
