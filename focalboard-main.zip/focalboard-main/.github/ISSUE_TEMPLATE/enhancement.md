---
name: Enhancement / Feature Idea
about: Suggest a new capability
title: 'Feature Idea: '
labels: enhancement
assignees: ''

---

**Summary:**
What the new capability is.

**How important this is to me and why:**

Importance: High/Medium/Low

Use cases:
1.
2.
3.

**Additional context / similar features:**
Any examples of good implementations of this capability.
